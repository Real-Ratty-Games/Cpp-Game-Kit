$input a_position, a_texcoord0
$output v_texcoord0

#include <common.sh>

uniform vec4 u_transform;
uniform vec4 u_flags;

void main()
{
	vec3 worldPos = u_model[0][3].xyz;
    vec3 right = u_view[0].xyz;

	vec3 up = u_view[1].xyz;
	if(u_flags.x >= 1.0)
		up = normalize(vec3(0.0, u_view[1].y, 0.0));

    vec2 quad = a_position.xy;
	quad -= u_transform.zw;

    vec3 offset = right * quad.x * u_transform.x
                + up    * quad.y * u_transform.y;

    vec4 pos = vec4(worldPos + offset, 1.0);
    gl_Position = mul(u_proj, mul(u_view, pos));
	
	// if(u_flags.y >= 1.0)
	// 	v_texcoord0 = vec2(a_texcoord0.x, 1.0 - a_texcoord0.y);
	// else v_texcoord0 = a_texcoord0;
	
	v_texcoord0 = vec2((u_flags.z >= 1.0) ? 1.0 - a_texcoord0.x : a_texcoord0.x, 
	(u_flags.y >= 1.0) ? 1.0 - a_texcoord0.y : a_texcoord0.y);
}
