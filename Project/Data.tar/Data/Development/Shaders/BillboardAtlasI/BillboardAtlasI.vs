$input a_position, a_texcoord0, i_data0, i_data1, i_data2, i_data3
$output v_texcoord0, v_color, v_index

#include <common.sh>

uniform vec4 u_transform;

void main()
{
	vec3 worldPos = i_data0.xyz;
    vec3 right = u_view[0].xyz;

	vec3 up = u_view[1].xyz;
	if(i_data1.z >= 1.0)
		up = normalize(vec3(0.0, u_view[1].y, 0.0));

    vec2 quad = a_position.xy;
	quad -= u_transform.zw;

    vec3 offset = right * quad.x * i_data1.x
                + up    * quad.y * i_data1.y;

    vec4 pos = vec4(worldPos + offset, 1.0);
    gl_Position = mul(u_proj, mul(u_view, pos));
	
	v_color = i_data2;
	v_index = i_data3;
	
	v_texcoord0 = vec2((i_data1.w >= 1.0) ? 1.0 - a_texcoord0.x : a_texcoord0.x, 
	(i_data0.w >= 1.0) ? 1.0 - a_texcoord0.y : a_texcoord0.y);
}
