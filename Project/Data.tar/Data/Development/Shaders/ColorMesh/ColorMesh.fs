$input v_texcoord0

#include <common.sh>

uniform vec4 u_color;

void main()
{
	gl_FragColor = u_color;
}
