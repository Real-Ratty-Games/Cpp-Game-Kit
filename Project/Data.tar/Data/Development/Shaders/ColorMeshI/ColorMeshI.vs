$input a_position, a_normal, a_texcoord0, a_tangent, a_bitangent, i_data0, i_data1, i_data2, i_data3, i_data4
$output v_texcoord0, v_color

#include <common.sh>

void main()
{
	v_texcoord0 = a_texcoord0;
	v_color = i_data4;

	mat4 model = mtxFromCols(i_data0, i_data1, i_data2, i_data3);
	vec4 aPos = vec4(a_position, 1.0);
	vec4 worldPos = mul(model, aPos);
	gl_Position = mul(u_viewProj, worldPos);
}
