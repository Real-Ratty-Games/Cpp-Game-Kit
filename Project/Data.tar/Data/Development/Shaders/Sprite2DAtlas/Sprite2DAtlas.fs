$input v_texcoord0

#include <common.sh>

SAMPLER2D(s_texColor, 0);

uniform vec4 u_atlasInfo[2];
uniform vec4 u_color;

void main()
{
	vec2 modifiedUV = v_texcoord0;
	
	float resX = (u_atlasInfo[0].z / u_atlasInfo[1].x);
	float resY = (u_atlasInfo[0].w / u_atlasInfo[1].y);
	vec2 offsetUv = vec2(u_atlasInfo[0].x / resX, u_atlasInfo[0].y / resY);
	modifiedUV = modifiedUV * vec2(1.0 / resX, 1.0 / resY) + offsetUv;

	gl_FragColor = texture2D(s_texColor, modifiedUV) * u_color;
}
