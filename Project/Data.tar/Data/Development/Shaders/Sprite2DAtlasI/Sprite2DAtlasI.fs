$input v_texcoord0, v_atlasInfo, v_color

#include <common.sh>

SAMPLER2D(s_texColor, 0);

uniform vec4 u_atlasInfo[2];

void main()
{
	vec2 modifiedUV = v_texcoord0;
	
	float resX = (u_atlasInfo[0].z / u_atlasInfo[1].x);
	float resY = (u_atlasInfo[0].w / u_atlasInfo[1].y);
	vec2 offsetUv = vec2(v_atlasInfo.x / resX, v_atlasInfo.y / resY);
	modifiedUV = modifiedUV * vec2(1.0 / resX, 1.0 / resY) + offsetUv;

	gl_FragColor = texture2D(s_texColor, modifiedUV) * v_color;
}
